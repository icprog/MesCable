﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace XML模拟数据上传
{
    class Program
    {
        private static int volumeCount = 0;

        private static System.Timers.Timer prodDataUploadTimer = new System.Timers.Timer();

        static void Main(string[] args)
        {
            Init();

            //生产数据上传任务
            prodDataUploadTimer.Interval = 15 * 60 * 1000;
            prodDataUploadTimer.Elapsed += prodDataUploadTimer_Elapsed;
            prodDataUploadTimer.Start();

            while (true)
            {
                Thread.Sleep(1000);
            }
        }

        private static void prodDataUploadTimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            Random random = new Random();
            ProcessTrace rootTrace = new ProcessTrace();
            DateTime completedDateTime = DateTime.Now.AddHours(-1000 - random.Next(20, 500));
            string volumeNo = ++volumeCount % 3 == 0 ? "16" : (volumeCount % 3 == 1 ? "13" : "14");
            string inkPrintVolume = GenerateInkPrintVolume(volumeNo, random.Next(1, 9),
                completedDateTime);

            rootTrace.InkPrintVolume = inkPrintVolume;
            rootTrace.CollectedTime = completedDateTime;
            ProcessTrace wholeTrace = GetProcessTrace(rootTrace);

            string xmlString = ModelToXmlWrapper.GetProcessDataXmlString(wholeTrace);
            string filePath = @"D:\HuaweiData\" + inkPrintVolume + ".xml";
            using (StreamWriter writer = new StreamWriter(filePath, true, Encoding.GetEncoding("GB2312")))
            {
                writer.Write(xmlString);
                writer.Flush();
            }
        }

        private static void Init()
        {
            // 读取线材参数配置
            string defaultJjyStock = XmlUtil.XmlGetElementText(XmlUtil.AppConfig,
                "/Application/DefaultJjyStock/@name");
            List<DataPattern> jjyDps = XmlUtil.GetModelFromXmlFile<DataPattern>(
                @"Config\CableTypes\挤绝缘\" + defaultJjyStock + ".xml");
            Dictionary<string, DataPattern> jjyDirectory = new Dictionary<string, DataPattern>();
            foreach (DataPattern dp in jjyDps)
            {
                jjyDirectory.Add(dp.DBFieldName, dp);
            }
            Configuration.Properties["JjyDps"] = jjyDirectory;

            string defaultJhtStock = XmlUtil.XmlGetElementText(XmlUtil.AppConfig,
                "/Application/DefaultJhtStock/@name");
            List<DataPattern> jhtDps = XmlUtil.GetModelFromXmlFile<DataPattern>(
                @"Config\CableTypes\挤护套\" + defaultJhtStock + ".xml");
            Dictionary<string, DataPattern> jhtDirectory = new Dictionary<string, DataPattern>();
            foreach (DataPattern dp in jhtDps)
            {
                jhtDirectory.Add(dp.DBFieldName, dp);
            }
            Configuration.Properties["JhtDps"] = jhtDirectory;
        }

        private static ProcessTrace GetProcessTrace(ProcessTrace rootTrace)
        {
            string machineNo = "90" + rootTrace.InkPrintVolume.Substring(10, 1) + "机台";
            rootTrace.MachineName = machineNo;

            // 挤护套
            rootTrace.ProcessDatas = ProcessDataDAL.generateProcessDatas(
                getDataPatterns(rootTrace.MachineName), rootTrace.MachineName,
                rootTrace.InkPrintVolume, null, 2000, rootTrace.CollectedTime);

            // 编织
            ProcessTrace bzTrace = new ProcessTrace();
            bzTrace.CollectedTime = rootTrace.CollectedTime.AddHours(-9.6);
            bzTrace.MachineName = "406编织";
            bzTrace.VolumeNo = "503031";
            bzTrace.VolumeNo += bzTrace.CollectedTime.Month.ToString("X2"); // 月
            bzTrace.VolumeNo += bzTrace.CollectedTime.Day.ToString("X2");   // 日
            bzTrace.VolumeNo += bzTrace.CollectedTime.Hour.ToString("X2");  // 时
            bzTrace.VolumeNo += bzTrace.CollectedTime.Minute.ToString("X2");// 分
            bzTrace.VolumeNo = "3430303651";


            // 成缆
            ProcessTrace clTrace = new ProcessTrace();
            clTrace.CollectedTime = rootTrace.CollectedTime.AddHours(-17.4);
            clTrace.MachineName = "308成缆";
            clTrace.VolumeNo = "503031";
            clTrace.VolumeNo += clTrace.CollectedTime.Month.ToString("X2"); // 月
            clTrace.VolumeNo += clTrace.CollectedTime.Day.ToString("X2");   // 日
            clTrace.VolumeNo += clTrace.CollectedTime.Hour.ToString("X2");  // 时
            clTrace.VolumeNo += clTrace.CollectedTime.Minute.ToString("X2");// 分
            clTrace.VolumeNo = "3330303851";


            // 挤绝缘
            ProcessTrace jjyTrace1 = new ProcessTrace();
            jjyTrace1.MachineName = "605机台";
            jjyTrace1.CollectedTime = rootTrace.CollectedTime.AddHours(-22.456);
            jjyTrace1.VolumeNo = "503031";
            jjyTrace1.VolumeNo += jjyTrace1.CollectedTime.Month.ToString("X2"); // 月
            jjyTrace1.VolumeNo += jjyTrace1.CollectedTime.Day.ToString("X2");   // 日
            jjyTrace1.VolumeNo += jjyTrace1.CollectedTime.Hour.ToString("X2");  // 时
            jjyTrace1.VolumeNo += jjyTrace1.CollectedTime.Minute.ToString("X2");// 分
            jjyTrace1.VolumeNo = "3336303551";

            jjyTrace1.ProcessDatas = ProcessDataDAL.generateProcessDatas(
                getDataPatterns(jjyTrace1.MachineName), jjyTrace1.MachineName,
                jjyTrace1.VolumeNo, null, 2000, jjyTrace1.CollectedTime);

            ProcessTrace jjyTrace2 = new ProcessTrace();
            jjyTrace2.MachineName = "606机台";
            jjyTrace2.CollectedTime = rootTrace.CollectedTime.AddHours(-20.423);
            jjyTrace2.VolumeNo = "503031";
            jjyTrace2.VolumeNo += jjyTrace2.CollectedTime.Month.ToString("X2"); // 月
            jjyTrace2.VolumeNo += jjyTrace2.CollectedTime.Day.ToString("X2");   // 日
            jjyTrace2.VolumeNo += jjyTrace2.CollectedTime.Hour.ToString("X2");  // 时
            jjyTrace2.VolumeNo += jjyTrace2.CollectedTime.Minute.ToString("X2");// 分
            jjyTrace2.VolumeNo = "3336303651";

            jjyTrace2.ProcessDatas = ProcessDataDAL.generateProcessDatas(
                getDataPatterns(jjyTrace2.MachineName), jjyTrace2.MachineName,
                jjyTrace2.VolumeNo, null, 2000, jjyTrace2.CollectedTime);

            clTrace.LastProcesses.Add(jjyTrace1);
            clTrace.LastProcesses.Add(jjyTrace2);

            bzTrace.LastProcesses.Add(clTrace);

            rootTrace.LastProcesses.Add(bzTrace);

            return rootTrace;
        }

        private static List<DataPattern> getDataPatterns(string machineNo)
        {
            List<DataPattern> dpList = new List<DataPattern>();
            Dictionary<string, DataPattern> list = null;
            if (machineNo.Contains("90"))
            {
                list = Configuration.Properties["JhtDps"] as Dictionary<string, DataPattern>;

            }
            else if (machineNo.Contains("60"))
            {
                list = Configuration.Properties["JjyDps"] as Dictionary<string, DataPattern>;
            }

            if (list != null)
            {
                dpList.Add(list["Firststress"] as DataPattern);
                dpList.Add(list["FinishedVelocity"] as DataPattern);
                dpList.Add(list["MotorVelocity"] as DataPattern);
                dpList.Add(list["Retained_field2"] as DataPattern);
                dpList.Add(list["Temperature1"] as DataPattern);
                dpList.Add(list["Temperature2"] as DataPattern);
                dpList.Add(list["Temperature3"] as DataPattern);
                dpList.Add(list["Temperature4"] as DataPattern);
                dpList.Add(list["Temperature5"] as DataPattern);
                dpList.Add(list["Temperature6"] as DataPattern);
                dpList.Add(list["Temperature7"] as DataPattern);
                dpList.Add(list["Temperature8"] as DataPattern);
                dpList.Add(list["Temperature9"] as DataPattern);
                dpList.Add(list["Temperature10"] as DataPattern);
                dpList.Add(list["OuterDiameter"] as DataPattern);

                if (machineNo.Contains("60"))
                {
                    dpList.Add(list["Retained_field7"] as DataPattern);
                }
            }

            return dpList;
        }

        /// <summary>
        /// 生成印制盘号
        /// </summary>
        /// <param name="machineNo"></param>
        /// <param name="volumeNo"></param>
        /// <param name="dateTime"></param>
        /// <returns></returns>
        private static string GenerateInkPrintVolume(string machineNo, int volumeNo, DateTime? dateTime = null)
        {
            StringBuilder inkPrintVolume = new StringBuilder("ZD");

            if (dateTime != null && dateTime.HasValue)
            {
                inkPrintVolume.Append(dateTime.Value.ToString("yyMMdd"));
                if (dateTime.Value.Hour > 8 && dateTime.Value.Hour < 20)
                    inkPrintVolume.Append("A");
                else
                    inkPrintVolume.Append("B");
            }
            else
            {
                inkPrintVolume.Append(DateTime.Now.ToString("yyMMdd"));
                if (DateTime.Now.Hour > 8 && DateTime.Now.Hour < 20)
                    inkPrintVolume.Append("A");
                else
                    inkPrintVolume.Append("B");
            }

            inkPrintVolume.Append(machineNo);
            if (volumeNo > 9)
                inkPrintVolume.Append(volumeNo);
            else
                inkPrintVolume.Append("0").Append(volumeNo);

            return inkPrintVolume.ToString();
        }
    }
}
