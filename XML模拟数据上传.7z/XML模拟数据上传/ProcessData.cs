﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace XML模拟数据上传
{
    public class ProcessData
    {
        private long auto_Id;
        public long Auto_Id
        {
            get { return auto_Id; }
            set { auto_Id = value; }
        }

        private int company_ID;
        public int Company_ID
        {
            get { return company_ID; }
            set { company_ID = value; }
        }

        private int contrast_ID;
        public int Contrast_ID
        {
            get { return contrast_ID; }
            set { contrast_ID = value; }
        }

        private string operator_RFID;
        public string Operator_RFID
        {
            get { return operator_RFID; }
            set { operator_RFID = value; }
        }

        private string machine_NO;
        public string Machine_NO
        {
            get { return machine_NO; }
            set { machine_NO = value; }
        }

        private string material_RFID;
        public string Material_RFID
        {
            get { return material_RFID; }
            set { material_RFID = value; }
        }

        private int temperature1;
        public int Temperature1
        {
            get { return temperature1; }
            set { temperature1 = value; }
        }

        private int temperature2;
        public int Temperature2
        {
            get { return temperature2; }
            set { temperature2 = value; }
        }

        private int temperature3;
        public int Temperature3
        {
            get { return temperature3; }
            set { temperature3 = value; }
        }

        private int temperature4;
        public int Temperature4
        {
            get { return temperature4; }
            set { temperature4 = value; }
        }

        private int temperature5;
        public int Temperature5
        {
            get { return temperature5; }
            set { temperature5 = value; }
        }

        private int temperature6;
        public int Temperature6
        {
            get { return temperature6; }
            set { temperature6 = value; }
        }

        private int temperature7;
        public int Temperature7
        {
            get { return temperature7; }
            set { temperature7 = value; }
        }

        private int temperature8;
        public int Temperature8
        {
            get { return temperature8; }
            set { temperature8 = value; }
        }

        private int temperature9;
        public int Temperature9
        {
            get { return temperature9; }
            set { temperature9 = value; }
        }

        private int temperature10;
        public int Temperature10
        {
            get { return temperature10; }
            set { temperature10 = value; }
        }

        private int temperatureSet1;
        public int TemperatureSet1
        {
            get { return temperatureSet1; }
            set { temperatureSet1 = value; }
        }

        private int temperatureSet2;
        public int TemperatureSet2
        {
            get { return temperatureSet2; }
            set { temperatureSet2 = value; }
        }

        private int temperatureSet3;
        public int TemperatureSet3
        {
            get { return temperatureSet3; }
            set { temperatureSet3 = value; }
        }

        private int temperatureSet4;
        public int TemperatureSet4
        {
            get { return temperatureSet4; }
            set { temperatureSet4 = value; }
        }

        private int temperatureSet5;
        public int TemperatureSet5
        {
            get { return temperatureSet5; }
            set { temperatureSet5 = value; }
        }

        private int temperatureSet6;
        public int TemperatureSet6
        {
            get { return temperatureSet6; }
            set { temperatureSet6 = value; }
        }

        private int temperatureSet7;
        public int TemperatureSet7
        {
            get { return temperatureSet7; }
            set { temperatureSet7 = value; }
        }

        private int temperatureSet8;
        public int TemperatureSet8
        {
            get { return temperatureSet8; }
            set { temperatureSet8 = value; }
        }

        private int temperatureSet9;
        public int TemperatureSet9
        {
            get { return temperatureSet9; }
            set { temperatureSet9 = value; }
        }

        private int temperatureSet10;
        public int TemperatureSet10
        {
            get { return temperatureSet10; }
            set { temperatureSet10 = value; }
        }

        private Single outerDiameter;
        public Single OuterDiameter
        {
            get { return outerDiameter; }
            set { outerDiameter = value; }
        }

        private Single outpress;
        public Single Outpress
        {
            get { return outpress; }
            set { outpress = value; }
        }

        private Single firststress;
        public Single Firststress
        {
            get { return firststress; }
            set { firststress = value; }
        }

        private Single savelineStress;
        public Single SavelineStress
        {
            get { return savelineStress; }
            set { savelineStress = value; }
        }

        private Single finishedStress;
        public Single FinishedStress
        {
            get { return finishedStress; }
            set { finishedStress = value; }
        }

        private int firstVelocity;
        public int FirstVelocity
        {
            get { return firstVelocity; }
            set { firstVelocity = value; }
        }

        private int motorVelocity;
        public int MotorVelocity
        {
            get { return motorVelocity; }
            set { motorVelocity = value; }
        }

        private int finishedVelocity;
        public int FinishedVelocity
        {
            get { return finishedVelocity; }
            set { finishedVelocity = value; }
        }

        private int concave_convex_value;
        public int Concave_convex_value
        {
            get { return concave_convex_value; }
            set { concave_convex_value = value; }
        }

        private int concave_convex_set_value;
        public int Concave_convex_set_value
        {
            get { return concave_convex_set_value; }
            set { concave_convex_set_value = value; }
        }

        private int spark_value;
        public int Spark_value
        {
            get { return spark_value; }
            set { spark_value = value; }
        }

        private int spark_set_value;
        public int Spark_set_value
        {
            get { return spark_set_value; }
            set { spark_set_value = value; }
        }

        private int last_meter;
        public int Last_meter
        {
            get { return last_meter; }
            set { last_meter = value; }
        }

        private int first_meter;
        public int First_meter
        {
            get { return first_meter; }
            set { first_meter = value; }
        }

        private DateTime collected_DATE;
        public DateTime Collected_DATE
        {
            get { return collected_DATE; }
            set { collected_DATE = value; }
        }

        private string volume_No;
        public string Volume_No
        {
            get { return volume_No; }
            set { volume_No = value; }
        }

        private string pro_Volume_No;
        public string Pro_Volume_No
        {
            get { return pro_Volume_No; }
            set { pro_Volume_No = value; }
        }

        private string meter_Tag;
        public string Meter_Tag
        {
            get { return meter_Tag; }
            set { meter_Tag = value; }
        }

        private string retained_field1;
        public string Retained_field1
        {
            get { return retained_field1; }
            set { retained_field1 = value; }
        }

        /// <summary>
        /// 主机螺杆速度
        /// </summary>
        private string retained_field2;
        public string Retained_field2
        {
            get { return retained_field2; }
            set { retained_field2 = value; }
        }

        private string retained_field3;
        public string Retained_field3
        {
            get { return retained_field3; }
            set { retained_field3 = value; }
        }

        private string retained_field4;
        public string Retained_field4
        {
            get { return retained_field4; }
            set { retained_field4 = value; }
        }

        private string retained_field5;
        public string Retained_field5
        {
            get { return retained_field5; }
            set { retained_field5 = value; }
        }

        private string retained_field6;
        public string Retained_field6
        {
            get { return retained_field6; }
            set { retained_field6 = value; }
        }

        /// <summary>
        /// 挤绝缘镀锡铜线直径
        /// </summary>
        private string retained_field7;
        public string Retained_field7
        {
            get { return retained_field7; }
            set { retained_field7 = value; }
        }

        /// <summary>
        /// 喷码机盘号
        /// </summary>
        private string retained_field8;
        public string Retained_field8
        {
            get { return retained_field8; }
            set { retained_field8 = value; }
        }

        /// <summary>
        /// 喷码机米数
        /// </summary>
        private string retained_field9;
        public string Retained_field9
        {
            get { return retained_field9; }
            set { retained_field9 = value; }
        }

        private string retained_field10;
        public string Retained_field10
        {
            get { return retained_field10; }
            set { retained_field10 = value; }
        }

        /// <summary>
        /// 湿度1
        /// </summary>
        private string retained_fielsd11;
        public string Retained_field11
        {
            get { return retained_fielsd11; }
            set { retained_fielsd11 = value; }
        }

        /// <summary>
        /// 温度1
        /// </summary>
        private string retained_field12;
        public string Retained_field12
        {
            get { return retained_field12; }
            set { retained_field12 = value; }
        }

        /// <summary>
        /// 湿度2
        /// </summary>
        private string retained_field13;
        public string Retained_field13
        {
            get { return retained_field13; }
            set { retained_field13 = value; }
        }

        /// <summary>
        /// 温度2
        /// </summary>
        private string retained_field14;
        public string Retained_field14
        {
            get { return retained_field14; }
            set { retained_field14 = value; }
        }

    }
}
