﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace XML模拟数据上传
{
    public class ModelToXmlWrapper
    {
        private static Random random = new Random();

        private static DateTime StartDateTime;
        private static DateTime EndDateTime;

        private static bool ItemTestPassed;
        private static bool ResultSetPasssed;

        private static string TestResults;
        private static string Personnel;
        private static string ResultSet;
        private static string TestProgram;
        private static string TestStation;
        private static string UUT;
        private static string WorkOrder;

        private static string ItemTest;
        private static string SubItemTest;

        private static readonly string DATETIME_FORMAT = "yyyy-MM-ddTHH:mm:ss";

        private static int Id, Index;
        private static int TestItemID;

        static ModelToXmlWrapper()
        {
            TestResults += "<?xml version=\"1.0\" encoding=\"GB2312\"?>\r\n";
            TestResults += "<TestResults xsi:schemaLocation=";
            TestResults += "\"" + @"http://www.ieee.org/ATML/2007/TestResults TestResults.xsd" + "\" xmlns=";
            TestResults += "\"" + @"http://www.ieee.org/ATML/2007/TestResults" + "\" xmlns:c=";
            TestResults += "\"" + @"http://www.ieee.org/ATML/2007/02/Common" + "\" xmlns:xsi=";
            TestResults += "\"" + @"http://www.w3.org/2001/XMLSchema-instance" + "\">\r\n";

            // Personnel
            Personnel += "\t<Personnel>\r\n\t\t<SystemOperator ID=\"C040345\"/>\r\n\t</Personnel>\r\n";

            // ResultSet
            ResultSet += "\t<ResultSet ID=\"1\" startDateTime=\"SDTR\" endDateTime=\"EDTR\" operationSequence=\"4\">\r\n";
            ResultSet += "\t\t<Description>CM021850</Description>\r\n";
            ResultSet += "\t\t<TestResult BoardFlag=\"0\" ID=\"1\">\r\n";
            ResultSet += "\t\t\t<Outcome value=\"OVR\"/>\r\n";
            ResultSet += "\t\t</TestResult>\r\n";

            // TestProgram
            TestProgram += "\t<TestProgram Productline=\"Wireless\" Product=\"RRU Cable\">\r\n";
            TestProgram += "\t\t<c:Definition name=\"ZhongDe TPS\" version=\"1.000\">\r\n";
            TestProgram += "\t\t\t<c:Description>NoDesc</c:Description>\r\n";
            TestProgram += "\t\t</c:Definition>\r\n";
            TestProgram += "\t</TestProgram>\r\n";

            // TestStation
            TestStation += "\t<TestStation AteName=\"ATECM021850A0001\" AteVersion=\"1.000\"/>\r\n";

            // UUT
            UUT += "\t<UUT UutType=\"hardware\">\r\n";
            UUT += "\t\t<SerialNumber></SerialNumber>\r\n";
            UUT += "\t\t<ItemName>Extruder</ItemName>\r\n";
            UUT += "\t\t<ItemCode>25030672</ItemCode>\r\n";
            UUT += "\t</UUT>\r\n";

            // WorkOrder
            WorkOrder += "\t<WorkOrder>\r\n";
            WorkOrder += "\t\t<WorkItem name=\"a\">\r\n";
            WorkOrder += "\t\t\t<c:Datum xsi:type=\"c:string\">\r\n";
            WorkOrder += "\t\t\t\t<c:Value>-</c:Value>\r\n";
            WorkOrder += "\t\t\t</c:Datum>\r\n";
            WorkOrder += "\t\t</WorkItem>\r\n";
            WorkOrder += "\t</WorkOrder>\r\n";

            // ItemTest
            ItemTest += "\t\t<ItemTest ID=\"IDR\" name=\"NER\" startDateTime=\"SDTR\" endDateTime=\"EDTR\">\r\n";
            ItemTest += "\t\t\t<TestResult ID=\"IDR\" BoardFlag=\"0\" SerialNumber=\"SNR\" ValueFlag=\"0\">\r\n";
            ItemTest += "\t\t\t\t<Outcome value=\"OVR\"/>\r\n";
            ItemTest += "\t\t\t\t<Description>NoDesc</Description>\r\n";
            ItemTest += "\t\t\t</TestResult>\r\n";

            // SubItemTest
            SubItemTest += "\t\t\t<SubItemTest ID=\"\" name=\"\">\r\n";
            SubItemTest += "\t\t\t\t<TestResult ID=\"\" BoardFlag=\"0\" SerialNumber=\"NoCode\">\r\n";
            SubItemTest += "\t\t\t\t\t<Outcome value=\"\"/>\r\n";
            SubItemTest += "\t\t\t\t\t<Description></Description>\r\n";
            SubItemTest += "\t\t\t\t\t<TestData>\r\n";
            SubItemTest += "\t\t\t\t\t\t<c:Datum xsi:type=\"c:string\">\r\n";
            SubItemTest += "\t\t\t\t\t\t\t<c:Value></c:Value>\r\n";
            SubItemTest += "\t\t\t\t\t\t</c:Datum>\r\n";
            SubItemTest += "\t\t\t\t\t</TestData>\r\n";
            SubItemTest += "\t\t\t\t</TestResult>\r\n";
            SubItemTest += "\t\t\t</SubItemTest>\r\n";
        }

        /// <summary>
        /// 根据传递的回溯参数获取整卷线的Xml字符串
        /// </summary>
        public static string GetProcessDataXmlString(ProcessTrace jhtTrace)
        {
            TestItemID = 1;
            string XmlString = string.Empty;
            ProcessTrace currentTrance = jhtTrace;

            StartDateTime = DateTime.MaxValue;
            EndDateTime = DateTime.MinValue;
            ResultSetPasssed = true;

            StringBuilder testResultsBuilder = new StringBuilder();

            // 挤护套
            testResultsBuilder.Append(GetJhtProcessDataXml(currentTrance));
            currentTrance = currentTrance.LastProcesses[0];

            // 编织
            StringBuilder itemTestBuilder = new StringBuilder(ItemTest);
            UpdateStartEndDateTime(currentTrance.CollectedTime, currentTrance.CollectedTime.AddHours(8));
            itemTestBuilder.Replace("IDR", "" + TestItemID++).Replace("NER", "Shielding")
                .Replace("SDTR", currentTrance.CollectedTime.ToString(DATETIME_FORMAT))
                .Replace("EDTR", currentTrance.CollectedTime.ToString(DATETIME_FORMAT))
                .Replace("SNR", currentTrance.VolumeNo).Replace("OVR", "Passed");
            testResultsBuilder.Append(itemTestBuilder.Append("\t\t</ItemTest>\r\n"));
            currentTrance = currentTrance.LastProcesses[0];

            // 成缆
            UpdateStartEndDateTime(currentTrance.CollectedTime, currentTrance.CollectedTime.AddMinutes(40));
            itemTestBuilder = new StringBuilder(ItemTest);
            itemTestBuilder.Replace("IDR", "" + TestItemID++).Replace("NER", "Cabling")
                .Replace("SDTR", currentTrance.CollectedTime.ToString(DATETIME_FORMAT))
                .Replace("EDTR", currentTrance.CollectedTime.ToString(DATETIME_FORMAT))
                .Replace("SNR", currentTrance.VolumeNo).Replace("OVR", "Passed");
            testResultsBuilder.Append(itemTestBuilder.Append("\t\t</ItemTest>\r\n"));

            // 挤绝缘
            if (currentTrance.LastProcesses != null && currentTrance.LastProcesses.Count > 0)
            {
                foreach (ProcessTrace processTrace in currentTrance.LastProcesses)
                {
                    testResultsBuilder.Append(GetJjyProcessDataXmlString(processTrace));
                }
            }

            StringBuilder resultSetBuilder = new StringBuilder(ResultSet);
            resultSetBuilder.Replace("SDTR", StartDateTime.ToString(DATETIME_FORMAT))
                .Replace("EDTR", EndDateTime.ToString(DATETIME_FORMAT))
                .Replace("OVR", ResultSetPasssed ? "Passed" : "Failed");

            return testResultsBuilder.Insert(0, resultSetBuilder).Insert(0, Personnel)
                .Insert(0, TestResults).Append("\t</ResultSet>\r\n").Append(TestProgram)
                .Append(TestStation).Append(UUT.Insert(43, jhtTrace.InkPrintVolume))
                .Append(WorkOrder).Append("</TestResults>").ToString();
        }

        /// <summary>
        /// 拼接作为ItemTest节点的挤护套工序数据的Xml字符串
        /// </summary>
        private static StringBuilder GetJhtProcessDataXml(ProcessTrace jhtTrace)
        {
            if (jhtTrace == null || jhtTrace.ProcessDatas == null || jhtTrace.ProcessDatas.Count == 0)
            {
                return new StringBuilder();
            }

            UpdateStartEndDateTime(jhtTrace.ProcessDatas.First().Collected_DATE,
                jhtTrace.ProcessDatas.Last().Collected_DATE);

            Id = 1;
            ItemTestPassed = true;
            Dictionary<string, DataPattern> jhtDic =
                Configuration.Properties["JhtDps"] as Dictionary<string, DataPattern>;

            StringBuilder itemTestHeader = new StringBuilder(ItemTest);
            itemTestHeader.Replace("IDR", "" + TestItemID++).Replace("NER", "Oversheath")
                .Replace("SDTR", jhtTrace.ProcessDatas.First().Collected_DATE.ToString(DATETIME_FORMAT))
                .Replace("EDTR", jhtTrace.ProcessDatas.Last().Collected_DATE.ToString(DATETIME_FORMAT))
                .Replace("SNR", jhtTrace.InkPrintVolume);

            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < jhtTrace.ProcessDatas.Count; i++)
            {
                Index = i + 1;
                ProcessData pd = jhtTrace.ProcessDatas[i];

                builder.Append(GetSubItemTestXml("Overall diameter", pd.OuterDiameter, jhtDic["OuterDiameter"]))
                    .Append(GetSubItemTestXml("Line speed", pd.FinishedVelocity, jhtDic["FinishedVelocity"]))
                    .Append(GetSubItemTestXml("Water temperature", pd.TemperatureSet10, jhtDic["Temperature10"]))
                    .Append(GetSubItemTestXml("Temperature 1", pd.Temperature1, jhtDic["Temperature1"]))
                    .Append(GetSubItemTestXml("Temperature 2", pd.Temperature2, jhtDic["Temperature2"]))
                    .Append(GetSubItemTestXml("Temperature 3", pd.Temperature3, jhtDic["Temperature3"]))
                    .Append(GetSubItemTestXml("Temperature 4", pd.Temperature4, jhtDic["Temperature4"]))
                    .Append(GetSubItemTestXml("Temperature 5", pd.Temperature5, jhtDic["Temperature5"]))
                    .Append(GetSubItemTestXml("Neck temperature", pd.Temperature7, jhtDic["Temperature7"]))
                    .Append(GetSubItemTestXml("Head temperature", pd.Temperature8, jhtDic["Temperature8"]))
                    .Append(GetSubItemTestXml("Mask temperature", pd.Temperature9, jhtDic["Temperature9"]))
                    .Append(GetSubItemTestXml("First stress", pd.Firststress, jhtDic["Firststress"]))
                    .Append(GetSubItemTestXml("Spark", pd.Spark_value, null));
            }

            itemTestHeader.Replace("OVR", ItemTestPassed ? "Passed" : "Failed");

            return itemTestHeader.Append(builder).Append("\t\t</ItemTest>\r\n");
        }

        /// <summary>
        /// 拼接作为ItemTest节点的挤绝缘工序数据的Xml字符串
        /// </summary>
        private static StringBuilder GetJjyProcessDataXmlString(ProcessTrace jjyTrace)
        {
            if (jjyTrace == null || jjyTrace.ProcessDatas == null || jjyTrace.ProcessDatas.Count == 0)
            {
                return new StringBuilder();
            }

            UpdateStartEndDateTime(jjyTrace.ProcessDatas.First().Collected_DATE,
                jjyTrace.ProcessDatas.Last().Collected_DATE);

            Dictionary<string, DataPattern> jjyDic =
                Configuration.Properties["JjyDps"] as Dictionary<string, DataPattern>;

            Id = 1;
            ItemTestPassed = true;
            StringBuilder itemTestHeader = new StringBuilder(ItemTest);
            if (jjyTrace.ProcessDatas != null && jjyTrace.ProcessDatas.Count > 0
                && string.IsNullOrEmpty(jjyTrace.ProcessDatas.First().Material_RFID))
            {
                string materialRfid = jjyTrace.ProcessDatas.First().Material_RFID.Split(',').First();
                if (materialRfid.StartsWith("523033"))
                {
                    itemTestHeader.Replace("IDR", "" + TestItemID++).Replace("NER", "Insulation black");
                }
                else if (materialRfid.StartsWith("523036"))
                {
                    itemTestHeader.Replace("IDR", "" + TestItemID++).Replace("NER", "Insulation blue");
                }
                else
                {
                    itemTestHeader.Replace("IDR", "" + TestItemID++).Replace("NER", "Insulation unknown");
                }
            }

            itemTestHeader.Replace("SDTR", jjyTrace.ProcessDatas.First().Collected_DATE.ToString(DATETIME_FORMAT))
                .Replace("EDTR", jjyTrace.ProcessDatas.Last().Collected_DATE.ToString(DATETIME_FORMAT))
                .Replace("SNR", jjyTrace.VolumeNo);

            StringBuilder builder = new StringBuilder();

            for (int i = 0; i < jjyTrace.ProcessDatas.Count; i++)
            {
                Index = i + 1;
                ProcessData pd = jjyTrace.ProcessDatas[i];

                double retained_field7;
                double.TryParse(pd.Retained_field7, out retained_field7);

                builder.Append(GetSubItemTestXml("Conductor diameter", retained_field7, jjyDic["Retained_field7"]))
                    .Append(GetSubItemTestXml("Insulation diameter", pd.OuterDiameter, jjyDic["OuterDiameter"]))
                    .Append(GetSubItemTestXml("Line speed", pd.FinishedVelocity, jjyDic["FinishedVelocity"]))
                    .Append(GetSubItemTestXml("Water temperature", pd.TemperatureSet10, jjyDic["Temperature10"]))
                    .Append(GetSubItemTestXml("Temperature 1", pd.Temperature1, jjyDic["Temperature1"]))
                    .Append(GetSubItemTestXml("Temperature 2", pd.Temperature2, jjyDic["Temperature2"]))
                    .Append(GetSubItemTestXml("Temperature 3", pd.Temperature3, jjyDic["Temperature3"]))
                    .Append(GetSubItemTestXml("Temperature 4", pd.Temperature4, jjyDic["Temperature4"]))
                    .Append(GetSubItemTestXml("Neck temperature", pd.Temperature7, jjyDic["Temperature7"]))
                    .Append(GetSubItemTestXml("Head temperature", pd.Temperature8, jjyDic["Temperature8"]))
                    .Append(GetSubItemTestXml("Mask temperature", pd.Temperature9, jjyDic["Temperature9"]))
                    .Append(GetSubItemTestXml("First stress", pd.Firststress, jjyDic["Firststress"]))
                    .Append(GetSubItemTestXml("Spark", pd.Spark_value, null));
            }

            itemTestHeader.Replace("OVR", ItemTestPassed ? "Passed" : "Failed");

            return itemTestHeader.Append(builder).Append("\t\t</ItemTest>\r\n");
        }

        /// <summary>
        /// 拼接处SubItemTest节点的Xml字符串
        /// </summary>
        private static StringBuilder GetSubItemTestXml(string name, double testValue, DataPattern dp)
        {
            StringBuilder builder = new StringBuilder(SubItemTest);
            builder.Insert(222, Index).Insert(136, Math.Round(testValue, 3));

            if (dp == null) // Spark_value
            {
                builder.Insert(113, "Passed");
            }
            else
            {
                if (testValue < dp.Lower || testValue > dp.Upper)
                {
                    builder.Insert(113, "Failed");
                    ResultSetPasssed = ItemTestPassed = false;
                }
                else
                {
                    builder.Insert(113, "Passed");
                }
            }

            return builder.Insert(52, Id).Insert(28, name).Insert(20, Id++);
        }

        /// <summary>
        /// 更新该卷线整个生产过程的开始时间和结束时间
        /// </summary>
        private static void UpdateStartEndDateTime(DateTime start, DateTime end)
        {
            if (StartDateTime > start)
                StartDateTime = start;

            if (EndDateTime < end)
                EndDateTime = end;
        }

        public static string GetObjectsXmlString<T>(List<T> objList)
        {
            if (objList == null && objList.Count == 0) { return null; }

            string xmlString = string.Empty;
            StringBuilder testResultsBuilder = new StringBuilder(TestResults);

            StringBuilder resultSetBuilder = new StringBuilder(ResultSet);
            resultSetBuilder.Replace("SDTR", DateTime.Now.ToString(DATETIME_FORMAT))
                .Replace("EDTR", DateTime.Now.ToString(DATETIME_FORMAT))
                .Replace("OVR", "Passed");

            Type type = objList[0].GetType();
            string className = type.ToString().Split('.').Last();

            for (int i = 0; i < objList.Count; i++)
            {
                StringBuilder itemTestBuilder = new StringBuilder(ItemTest);

                itemTestBuilder.Replace("IDR", "" + (i + 1))
                    .Replace("SDTR", DateTime.Now.ToString(DATETIME_FORMAT))
                    .Replace("EDTR", DateTime.Now.ToString(DATETIME_FORMAT))
                    .Replace("SNR", "NoCode").Replace("NER", className).Replace("OVR", "Passed");

                // 获取类型的所有属性及其数据类型
                PropertyInfo[] props = type.GetProperties();
                List<string> propNames = new List<string>();
                List<Type> propTypes = new List<Type>();
                foreach (var prop in props)
                {
                    propNames.Add(prop.Name);
                    propTypes.Add(prop.PropertyType);
                }

                for (int j = 1; j < propNames.Count; j++)
                {
                    int id = propNames.Count * i + j;
                    StringBuilder builder = new StringBuilder(SubItemTest).Insert(222, i + 1);

                    PropertyInfo property = type.GetProperty(propNames[j]);
                    object propValue = property.GetValue(objList[i], null);

                    if (propValue != null)
                    {
                        builder.Insert(136, propValue.ToString());
                    }
                    else
                    {
                        builder.Insert(136, "NoDesc");
                    }
                    builder.Insert(113, "Passed");
                    builder.Insert(52, id).Insert(28, propNames[j]).Insert(20, id);

                    itemTestBuilder.Append(builder);
                }
                resultSetBuilder.Append(itemTestBuilder.Append("\t\t</ItemTest>\r\n"));
            }
            resultSetBuilder.Append("\t</ResultSet>\r\n");

            return testResultsBuilder.Append(Personnel).Append(resultSetBuilder)
                .Append(TestProgram).Append(TestStation).Append(UUT.Insert(43, "CM021850"))
                .Append(WorkOrder).Append("</TestResults>").ToString();
        }
    }
}
