﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XML模拟数据上传
{
    public class Configuration
    {
        /// <summary>
        /// 存储应用程序级的公共信息
        /// </summary>
        public static Dictionary<string, object> Properties = new Dictionary<string, object>();
    }
}
