﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows;

namespace XML模拟数据上传
{
    /// <summary>
    /// 生产数据
    /// </summary>
    public class ProcessDataDAL
    {
        /// <summary>
        /// 随机数发生器
        /// </summary>
        private static Random radom = new Random();

        /// <summary>
        /// 时间的格式化形式
        /// </summary>
        private static string DATETIME_FORMAT = "yyyy-MM-dd HH:mm:ss.fff";

        /// <summary>
        /// 获取最新的存储生产数据的表
        /// </summary>
        /// <returns></returns>
        private static string GetTableName()
        {
            return "[" + DateTime.Now.Year.ToString() + "-" + DateTime.Now.Month.ToString() + "]";
        }

        /// <summary>
        /// 获取指定时间存储生产数据的表
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        private static string GetTableName(DateTime dt)
        {
            return "[" + dt.Year.ToString() + "-" + dt.Month.ToString() + "]";
        }

        /// <summary>
        /// 从一个SqlDataReader中获取ProcessData对象
        /// </summary>
        /// <param name="dr"></param>
        /// <returns></returns>
        private static List<ProcessData> GetProcessDataFromDR(SqlDataReader dr)
        {
            try
            {
                ProcessData processData = null;
                List<ProcessData> tList = new List<ProcessData>();
                while (dr != null && dr.Read())
                {
                    processData = new ProcessData();
                    processData.Auto_Id = Convert.ToInt64(dr["Auto_Id"]);
                    if (DBNull.Value != dr["Company_ID"])
                        processData.Company_ID = Convert.ToInt32(dr["Company_ID"]);
                    if (DBNull.Value != dr["contrast_ID"])
                        processData.Contrast_ID = Convert.ToInt32(dr["contrast_ID"]);
                    if (DBNull.Value != dr["Operator_RFID"])
                        processData.Operator_RFID = dr["Operator_RFID"].ToString();
                    if (DBNull.Value != dr["Machine_NO"])
                        processData.Machine_NO = dr["Machine_NO"].ToString();
                    if (DBNull.Value != dr["Material_RFID"])
                        processData.Material_RFID = dr["Material_RFID"].ToString();
                    if (DBNull.Value != dr["Temperature1"])
                        processData.Temperature1 = Convert.ToInt32(dr["Temperature1"]);
                    if (DBNull.Value != dr["Temperature2"])
                        processData.Temperature2 = Convert.ToInt32(dr["Temperature2"]);
                    if (DBNull.Value != dr["Temperature3"])
                        processData.Temperature3 = Convert.ToInt32(dr["Temperature3"]);
                    if (DBNull.Value != dr["Temperature4"])
                        processData.Temperature4 = Convert.ToInt32(dr["Temperature4"]);
                    if (DBNull.Value != dr["Temperature5"])
                        processData.Temperature5 = Convert.ToInt32(dr["Temperature5"]);
                    if (DBNull.Value != dr["Temperature6"])
                        processData.Temperature6 = Convert.ToInt32(dr["Temperature6"]);
                    if (DBNull.Value != dr["Temperature7"])
                        processData.Temperature7 = Convert.ToInt32(dr["Temperature7"]);
                    if (DBNull.Value != dr["Temperature8"])
                        processData.Temperature8 = Convert.ToInt32(dr["Temperature8"]);
                    if (DBNull.Value != dr["Temperature9"])
                        processData.Temperature9 = Convert.ToInt32(dr["Temperature9"]);
                    if (DBNull.Value != dr["Temperature10"])
                        processData.Temperature10 = Convert.ToInt32(dr["Temperature10"]);
                    if (DBNull.Value != dr["TemperatureSet1"])
                        processData.TemperatureSet1 = Convert.ToInt32(dr["TemperatureSet1"]);
                    if (DBNull.Value != dr["TemperatureSet2"])
                        processData.TemperatureSet2 = Convert.ToInt32(dr["TemperatureSet2"]);
                    if (DBNull.Value != dr["TemperatureSet3"])
                        processData.TemperatureSet3 = Convert.ToInt32(dr["TemperatureSet3"]);
                    if (DBNull.Value != dr["TemperatureSet4"])
                        processData.TemperatureSet4 = Convert.ToInt32(dr["TemperatureSet4"]);
                    if (DBNull.Value != dr["TemperatureSet5"])
                        processData.TemperatureSet5 = Convert.ToInt32(dr["TemperatureSet5"]);
                    if (DBNull.Value != dr["TemperatureSet6"])
                        processData.TemperatureSet6 = Convert.ToInt32(dr["TemperatureSet6"]);
                    if (DBNull.Value != dr["TemperatureSet7"])
                        processData.TemperatureSet7 = Convert.ToInt32(dr["TemperatureSet7"]);
                    if (DBNull.Value != dr["TemperatureSet8"])
                        processData.TemperatureSet8 = Convert.ToInt32(dr["TemperatureSet8"]);
                    if (DBNull.Value != dr["TemperatureSet9"])
                        processData.TemperatureSet9 = Convert.ToInt32(dr["TemperatureSet9"]);
                    if (DBNull.Value != dr["TemperatureSet10"])
                        processData.TemperatureSet10 = Convert.ToInt32(dr["TemperatureSet10"]);
                    if (DBNull.Value != dr["OuterDiameter"])
                        processData.OuterDiameter = Convert.ToSingle(dr["OuterDiameter"]);
                    if (DBNull.Value != dr["Outpress"])
                        processData.Outpress = Convert.ToSingle(dr["Outpress"]);
                    if (DBNull.Value != dr["Firststress"])
                        processData.Firststress = Convert.ToSingle(dr["Firststress"]);
                    if (DBNull.Value != dr["SavelineStress"])
                        processData.SavelineStress = Convert.ToSingle(dr["SavelineStress"]);
                    if (DBNull.Value != dr["FinishedStress"])
                        processData.FinishedStress = Convert.ToSingle(dr["FinishedStress"]);
                    if (DBNull.Value != dr["FirstVelocity"])
                        processData.FirstVelocity = Convert.ToInt32(dr["FirstVelocity"]);
                    if (DBNull.Value != dr["MotorVelocity"])
                        processData.MotorVelocity = Convert.ToInt32(dr["MotorVelocity"]);
                    if (DBNull.Value != dr["FinishedVelocity"])
                        processData.FinishedVelocity = Convert.ToInt32(dr["FinishedVelocity"]);
                    if (DBNull.Value != dr["concave_convex_value"])
                        processData.Concave_convex_value = Convert.ToInt32(dr["concave_convex_value"]);
                    if (DBNull.Value != dr["concave_convex_set_value"])
                        processData.Concave_convex_set_value = Convert.ToInt32(dr["concave_convex_set_value"]);
                    if (DBNull.Value != dr["Spark_value"])
                        processData.Spark_value = Convert.ToInt32(dr["Spark_value"]);
                    if (DBNull.Value != dr["Spark_set_value"])
                        processData.Spark_set_value = Convert.ToInt32(dr["Spark_set_value"]);
                    if (DBNull.Value != dr["Last_meter"])
                        processData.Last_meter = Convert.ToInt32(dr["Last_meter"]);
                    if (DBNull.Value != dr["First_meter"])
                        processData.First_meter = Convert.ToInt32(dr["First_meter"]);
                    if (DBNull.Value != dr["Collected_DATE"])
                        processData.Collected_DATE = Convert.ToDateTime(dr["Collected_DATE"]);
                    if (DBNull.Value != dr["Volume_No"])
                        processData.Volume_No = dr["Volume_No"].ToString();
                    if (DBNull.Value != dr["Pro_Volume_No"])
                        processData.Pro_Volume_No = dr["Pro_Volume_No"].ToString();
                    if (DBNull.Value != dr["Meter_Tag"])
                        processData.Meter_Tag = dr["Meter_Tag"].ToString();
                    if (DBNull.Value != dr["Retained_field1"])
                        processData.Retained_field1 = dr["Retained_field1"].ToString();
                    if (DBNull.Value != dr["Retained_field2"])
                        processData.Retained_field2 = dr["Retained_field2"].ToString();
                    if (DBNull.Value != dr["Retained_field3"])
                        processData.Retained_field3 = dr["Retained_field3"].ToString();
                    if (DBNull.Value != dr["Retained_field4"])
                        processData.Retained_field4 = dr["Retained_field4"].ToString();
                    if (DBNull.Value != dr["Retained_field5"])
                        processData.Retained_field5 = dr["Retained_field5"].ToString();
                    if (DBNull.Value != dr["Retained_field6"])
                        processData.Retained_field6 = dr["Retained_field6"].ToString();
                    if (DBNull.Value != dr["Retained_field7"])
                        processData.Retained_field7 = dr["Retained_field7"].ToString();
                    if (DBNull.Value != dr["Retained_field8"])
                        processData.Retained_field8 = dr["Retained_field8"].ToString();
                    if (DBNull.Value != dr["Retained_field9"])
                        processData.Retained_field9 = dr["Retained_field9"].ToString();
                    if (DBNull.Value != dr["Retained_field10"])
                        processData.Retained_field10 = dr["Retained_field10"].ToString();
                    if (DBNull.Value != dr["Retained_field11"])
                        processData.Retained_field11 = dr["Retained_field11"].ToString();
                    if (DBNull.Value != dr["Retained_field12"])
                        processData.Retained_field12 = dr["Retained_field12"].ToString();
                    if (DBNull.Value != dr["Retained_field13"])
                        processData.Retained_field13 = dr["Retained_field13"].ToString();
                    if (DBNull.Value != dr["Retained_field14"])
                        processData.Retained_field14 = dr["Retained_field14"].ToString();
                    tList.Add(processData);
                }
                return tList;
            }
            catch { }
            return null;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dps"></param>
        /// <param name="machineNo"></param>
        /// <param name="volumeNo"></param>
        /// <param name="count">制定查询的数据条数</param>
        /// <param name="dt"></param>
        /// <param name="after">制定船哪一个月的数据</param>
        /// <returns></returns>
        public static List<ProcessData> generateProcessDatas(List<DataPattern> dps, string machineNo,
            string volumeNo, DateTime? after, int count = 0, DateTime? before = null)
        {
            List<ProcessData> pdList = new List<ProcessData>();
            if (count <= 0 && after != null && after.HasValue)
            {
                TimeSpan ts = DateTime.Now - after.Value;
                for (DateTime start = after.Value; ts.TotalSeconds > 0 && start <= DateTime.Now;
                    start = start.AddSeconds(1))
                {
                    ProcessData pd = generateProcessData(dps, machineNo, volumeNo);
                    pd.Collected_DATE = start;
                    pdList.Add(pd);
                }
            }
            else if (after == null && count > 0 && before != null && before.HasValue)
            {
                for (int i = 0; i < count; i++)
                {
                    ProcessData pd = generateProcessData(dps, machineNo, volumeNo, i + 1);
                    pd.Collected_DATE = before.Value.AddSeconds(i - count);
                    pdList.Add(pd);
                }
            }
            return pdList;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dps"></param>
        /// <param name="machineNo"></param>
        /// <param name="volumeNo"></param>
        /// <returns></returns>
        private static ProcessData generateProcessData(List<DataPattern> dps,
            string machineNo, string volumeNo, int meter = -1)
        {
            Type type = typeof(ProcessData);
            ProcessData pd = new ProcessData();
            foreach (DataPattern dp in dps)
            {
                double center = (dp.Upper + dp.Lower) / 2.0;
                double halfDelta = (dp.Upper - dp.Lower) / 4.0;
                object value = center + (radom.NextDouble() - 0.5) * halfDelta;

                string propTypeName = type.GetProperty(dp.DBFieldName).PropertyType.ToString();
                if (propTypeName.Equals("System.String"))
                {
                    value = Convert.ToString(value);
                }
                else if (propTypeName.Equals("System.Single"))
                {
                    value = Convert.ToSingle(value);
                }
                else if (propTypeName.Equals("System.Int32"))
                {
                    value = Convert.ToInt32(value);
                }

                type.InvokeMember(dp.DBFieldName, BindingFlags.SetProperty | BindingFlags.Public
                            | BindingFlags.Instance, null, pd, new object[] { value });
            }

            pd.Machine_NO = machineNo;
            pd.Material_RFID = "R02162700010,R02162700011,R02162700012";

            if (machineNo.Contains("605"))
            {
                pd.Operator_RFID = "潘卫国";
            }
            else if (machineNo.Contains("606"))
            {
                pd.Operator_RFID = "朱兴武";
            }
            else
            {
                pd.Operator_RFID = "严智权";
            }

            pd.Volume_No = volumeNo;

            string pro_volume_no = DateTime.Now.ToString(DATETIME_FORMAT);
            if (machineNo.Contains("成缆"))
            {
                pro_volume_no += "," + DateTime.Now.AddHours(37).ToString(DATETIME_FORMAT);
            }
            pd.Pro_Volume_No = pro_volume_no;

            // 米数
            if (meter > 0)
            {
                pd.Last_meter = meter;
            }
            else
            {
                pd.Last_meter = (int)(TimeSpan.FromTicks(DateTime.Now.Ticks).TotalSeconds % 2000);
            }

            // 喷码机盘号
            if (string.IsNullOrEmpty(volumeNo))
            {
                pd.Retained_field8 = "ZD16" + DateTime.Now.ToString("MMdd") + "A1" +
                    machineNo.Substring(2, 1) + "02";
            }
            else
            {
                pd.Retained_field8 = volumeNo;
            }
            // 喷码机米数
            pd.Retained_field9 = "" + meter;

            // 湿度1
            pd.Retained_field11 = "" + (81.1 + radom.NextDouble() * 3.0);
            // 温度1
            pd.Retained_field12 = "" + (31.1 + radom.NextDouble() * 1.0);
            // 湿度2
            pd.Retained_field13 = "" + (78.1 + radom.NextDouble() * 4.0);
            // 温度2
            pd.Retained_field14 = "" + (30.3 + radom.NextDouble() * 1.3);

            return pd;
        }

        private static List<DataPattern> getDataPatterns(string machineNo)
        {
            List<DataPattern> dpList = new List<DataPattern>();
            Dictionary<string, DataPattern> list = null;
            if (machineNo.Contains("90"))
            {
                list = Configuration.Properties["JhtDps"] as Dictionary<string, DataPattern>;
            }
            else if (machineNo.Contains("60"))
            {
                list = Configuration.Properties["JjyDps"] as Dictionary<string, DataPattern>;
            }

            if (list != null)
            {
                dpList.Add(list["Firststress"] as DataPattern);
                dpList.Add(list["FinishedVelocity"] as DataPattern);
                dpList.Add(list["MotorVelocity"] as DataPattern);
                dpList.Add(list["Retained_field2"] as DataPattern);
                dpList.Add(list["Temperature1"] as DataPattern);
                dpList.Add(list["Temperature2"] as DataPattern);
                dpList.Add(list["Temperature3"] as DataPattern);
                dpList.Add(list["Temperature4"] as DataPattern);
                dpList.Add(list["Temperature5"] as DataPattern);
                dpList.Add(list["Temperature6"] as DataPattern);
                dpList.Add(list["Temperature7"] as DataPattern);
                dpList.Add(list["Temperature8"] as DataPattern);
                dpList.Add(list["Temperature9"] as DataPattern);
                dpList.Add(list["Temperature10"] as DataPattern);
                dpList.Add(list["OuterDiameter"] as DataPattern);

                if (machineNo.Contains("60"))
                {
                    dpList.Add(list["Retained_field7"] as DataPattern);
                }
            }

            return dpList;
        }
    }
}
