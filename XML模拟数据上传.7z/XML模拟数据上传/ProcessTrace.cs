﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XML模拟数据上传
{
    /// <summary>
    /// 回溯时的工序信息
    /// </summary>
    public class ProcessTrace
    {
        /// <summary>
        /// 机台名称
        /// </summary>
        public String MachineName { get; set; }

        /// <summary>
        /// 如果是挤绝缘，其表示该卷线为挤绝缘的后2000米
        /// </summary>
        public bool IsSecondInJJY { get; set; }

        /// <summary>
        /// 用于绘制回溯的关系图
        /// </summary>
        private double leftMargin;

        /// <summary>
        /// 回溯到的那卷线的卷号(半成品盘号)
        /// </summary>
        /* 50 30 31 02 02 09 0B 30 36 30 34 50 */
        private string volumeNo;
        public string VolumeNo
        {
            get { return volumeNo; }
            set
            {
                volumeNo = value;
                if(!string.IsNullOrEmpty(volumeNo) && volumeNo.Length >= 14)
                {
                    try
                    {
                        int month = Convert.ToInt32(volumeNo.Substring(6, 2), 16);
                        CollectedTime = new DateTime(DateTime.Now.Year, month, 15);
                    }
                    catch { }
                }
            }
        }

        /// <summary>
        /// 挤护套工序的印制盘号
        /// </summary>
        /* 5A 44 31 36 30 31 32 30 42 31 36 30 31 */
        private string inkPrintVolume;
        public string InkPrintVolume
        {
            get { return inkPrintVolume; }
            set
            {
                inkPrintVolume = value;
                if(!string.IsNullOrEmpty(inkPrintVolume))
                {
                    try
                    {
                        int year = int.Parse(inkPrintVolume.Substring(2, 2)) + 2000;
                        int month = int.Parse(inkPrintVolume.Substring(4, 2));
                        int day = int.Parse(inkPrintVolume.Substring(6, 2));

                        CollectedTime = new DateTime(year, month, day);
                    }
                    catch { }
                }
            }
        }
        /// <summary>
        /// 回溯哪一个月的数据
        /// </summary>
        public DateTime CollectedTime { get; set; }

        /// <summary>
        /// 存储回溯到的该工序的生产数据
        /// </summary>
        public List<ProcessData> ProcessDatas { get; set; }

        /// <summary>
        /// 检测回溯信息的完备性
        /// </summary>
        /// <returns></returns>
        public bool CheckIntegrity()
        {
            if(CollectedTime == DateTime.MinValue)
                return false;

            if(!string.IsNullOrEmpty(InkPrintVolume) ||
                !string.IsNullOrEmpty(VolumeNo))
                return true;

            return false;
        }

        /// <summary>
        /// 根据回溯信息生成查询该工序生产数据的where语句
        /// </summary>
        /// <returns></returns>
        public string GetWhereString()
        {
            if(CollectedTime == DateTime.MinValue)
                return null;

            if(!string.IsNullOrEmpty(InkPrintVolume))
                return "where Retained_field8='" + InkPrintVolume + "'";

            if(!string.IsNullOrEmpty(VolumeNo))
                return "where Volume_No='" + VolumeNo + "'";

            return null;
        }

        /// <summary>
        /// 上一道工序
        /// </summary>
        public List<ProcessTrace> LastProcesses { get; set; }

        public ProcessTrace()
        {
            LastProcesses = new List<ProcessTrace>();
        }

        public double GetLeftMargin()
        {
            return this.leftMargin;
        }

        public void SetLeftMargin(double leftMargin)
        {
            this.leftMargin = leftMargin;
        }
    }
}
